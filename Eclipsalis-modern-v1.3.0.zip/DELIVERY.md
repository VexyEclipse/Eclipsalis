Eclipsalis v1.3.0 - Modern monochrome interface

One full-width feature per vertical row, rounded panels and sidebar tabs, soft white glows, pill switches and simple eased animations. Original supplied flame logo; fixed 520 x 320 window with no resizing.

Library/example and Premium wrappers/extracted runtime compile; 33 focused local layout/glow/switch checks pass. Roblox rendering/touch and frame cost remain unverified.

Not published: GitHub write access was rejected with HTTP 403. This archive uses the repository layout. EclipseUI.lua is the complete generated module. Run python build_ui.py after UI source edits.
